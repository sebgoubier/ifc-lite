"""Evidence-only finite-surface sample distances and stable local integrals.
No fitting/alignment, tolerance acceptance, or full Hausdorff/equivalence claim.
"""
from pathlib import Path
import json,struct,hashlib
import numpy as np
root=Path(__file__).resolve().parent
payload=root/'rvt-causal/final11a-primary-alt-source-cut/rvt-payload.json';data=json.load(open(payload))
def f64(bits):return struct.unpack('>d',bytes.fromhex(bits))[0]
def f32s(bits):return np.frombuffer(struct.pack('<'+'I'*len(bits),*bits),dtype='<f4').astype(np.float64)
rtc=np.array([f64(x) for x in data['modelFrameRtcOffsetBits']])
def metrics(points,faces):
 t=points[faces];cross=np.cross(t[:,1]-t[:,0],t[:,2]-t[:,0]);area=float(np.linalg.norm(cross,axis=1).sum()/2);ref=(points.min(axis=0)+points.max(axis=0))/2;v=t-ref
 return {'area':area,'signedDivergenceVolume':float(np.einsum('ij,ij->i',v[:,0],np.cross(v[:,1],v[:,2])).sum()/6),'bboxMin':points.min(axis=0).tolist(),'bboxMax':points.max(axis=0).tolist(),'volumeInterpretation':'algebraic integral; aggregate nonmanifold/open meshes not certified solid volumes'}
def samples(p,f):
 t=p[f];return np.concatenate([p,t.mean(axis=1),(t[:,0]+t[:,1])/2,(t[:,1]+t[:,2])/2,(t[:,2]+t[:,0])/2])
def distances(points,triangles):
 a,b,c=triangles[:,0],triangles[:,1],triangles[:,2];ab=b-a;ac=c-a;n=np.cross(ab,ac);n2=np.einsum('ij,ij->i',n,n);valid=n2>0;a,b,c,ab,ac,n,n2=[x[valid] for x in [a,b,c,ab,ac,n,n2]];d00=np.einsum('ij,ij->i',ab,ab);d01=np.einsum('ij,ij->i',ab,ac);d11=np.einsum('ij,ij->i',ac,ac);den=d00*d11-d01*d01;result=[]
 for p in points:
  ap=p-a;off=np.einsum('ij,ij->i',ap,n);q=ap-n*(off/n2)[:,None];d20=np.einsum('ij,ij->i',q,ab);d21=np.einsum('ij,ij->i',q,ac);v=np.einsum('ij,ij->i',np.cross(q,ac),n)/n2;w=np.einsum('ij,ij->i',np.cross(ab,q),n)/n2;inside=(v>=0)&(w>=0)&(v+w<=1);d=np.where(inside,off*off/n2,np.inf)
  for u,z in [(a,b),(b,c),(c,a)]:
   e=z-u;e2=np.einsum('ij,ij->i',e,e);parameter=np.clip(np.einsum('ij,ij->i',p-u,e)/e2,0,1);difference=p-(u+e*parameter[:,None]);d=np.minimum(d,np.einsum('ij,ij->i',difference,difference))
  result.append(float(np.sqrt(d.min())))
 return np.array(result)
rows=[]
for r in data['rows']:
 host=r['host'];oraclemode='source' if r['context']=='source' else 'cut';oraclefile=root/f'rvt-four-wall-authoring-oracle-085-v1/{host}-{oraclemode}.json'
 oracle=json.load(open(oraclefile));placement=np.array(oracle['placementInIfcUnits']);rotation=placement[:3,:3];translation=placement[:3,3];origin=np.array([f64(x) for x in r['originBits']]);native=(f32s(r['positionsBits']).reshape(-1,3)+origin+(rtc-translation))@rotation;faces=np.array(r['indices']).reshape(-1,3);reference=(np.array(oracle['vertices']).reshape(-1,3)-translation)@rotation;referencefaces=np.array(oracle['faces']).reshape(-1,3)
 forward=distances(samples(native,faces),reference[referencefaces]);reverse=distances(samples(reference,referencefaces),native[faces]);nm=metrics(native,faces);om=metrics(reference,referencefaces)
 row={k:r[k] for k in ['host','alternate','context']}|{'native':nm,'oracle':om,'areaDelta':nm['area']-om['area'],'signedDivergenceVolumeDelta':nm['signedDivergenceVolume']-om['signedDivergenceVolume'],'finiteSampleDistances':{'nativeToOracleMax':float(forward.max()),'oracleToNativeMax':float(reverse.max()),'nativeSamples':len(forward),'oracleSamples':len(reverse),'nativeMaxSampleIndex':int(forward.argmax()),'oracleMaxSampleIndex':int(reverse.argmax()),'scope':'vertices, trianglecentroids andedge midpoints only; finite triangles used for target distance. This is not a Hausdorff/equivalence certificate.'}}
 rows.append(row);print(host,r['alternate'],r['context'],'areaDelta',row['areaDelta'],'volumeIntegralDelta',row['signedDivergenceVolumeDelta'],'samplesMax',float(forward.max()),float(reverse.max()),flush=True)
out=root/'rvt-causal/final11a-primary-alt-source-cut/physical-finite-sample-comparison-v2.json';out.write_text(json.dumps({'payloadSha256':hashlib.sha256(payload.read_bytes()).hexdigest(),'scriptSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'frame':'ActualModelFrameRTC +mesh origin/positions mapped by oracleauthoredplacement inverse; no bboxfit/snapping','warning':'Sampled finite-surface comparison only; aggregate nonmanifold volume integrals are not certified physical volume.','rows':rows},indent=2))
