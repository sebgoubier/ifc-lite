pub(super) fn recover_missing_boundaries(
    data: &[f64],
    holes: &[usize],
    earcut: &[usize],
) -> Option<Vec<usize>> {
    let result=diag_7631_recover_missing_boundaries(data,holes,earcut);
    if let Some(path)=std::env::var_os("IFC_DIAG_7631_RVT_TRACE") {
        use std::io::Write as _;
        let mut file=std::fs::OpenOptions::new().create(true).append(true).open(path).expect("cap trace file");
        let output=result.as_ref().map(|v|format!("{v:?}")).unwrap_or_else(||"null".to_owned());
        writeln!(file,"{{\"event\":\"cap-recovery\",\"dataBits\":{:?},\"holes\":{:?},\"earcut\":{:?},\"result\":{}}}",data.iter().map(|v|format!("{:016x}",v.to_bits())).collect::<Vec<_>>(),holes,earcut,output).expect("write cap trace");
    }
    result
}
fn diag_7631_recover_missing_boundaries(
    data: &[f64],
    holes: &[usize],
    earcut: &[usize],
) -> Option<Vec<usize>> {
