"""One authorized serial validation lane; no fixes, retries, publishing or capture."""
import ctypes
import datetime
import hashlib
import json
import os
import re
from pathlib import Path
import signal
import subprocess
import time

ROOT = Path('/home/louistrue/wt/6940-parent-26f538-census-20261018')
OUT = Path('/home/louistrue/.t3/worktrees/ifc-lite/t3code-818b4671/work/6940/zbook-resume-20261017/wsl-parent-26f538-census-actual')
HEAD = '26f538d7cdf21b6da66ebab1129b059d3945b390'
GUARD = '/home/louistrue/build-workers/setup/build-capacity-guard.py'
EXPECTED_PINS = {'candidate': {'path': '/home/louistrue/wt/6940-parent-26f538-census-20261018', 'head': HEAD, 'diffSHA256': hashlib.sha256(b'').hexdigest(), 'status': ''}}
EXPECTED_LOCK_SHA256 = 'd19c45c892239d9972b1443a2db16b067db1f953dce484eeab460994244ad5b4'
FIXTURE_PINS = [{'path': '/home/louistrue/wt/6940-parent-26f538-census-20261018/tests/models/georeferencer/MiniBIM-3.1-DO_01_VORM.ifc', 'sha256': '7d3ae097a2f1ca5e63f7698d12215cb58427cdb6a932e75e6bf1ca222bcf873b'}, {'path': '/home/louistrue/wt/6940-parent-26f538-census-20261018/tests/models/various/rvt01.ifc', 'sha256': 'a83e9aacb43c7f82955ee3ba650ec66dc24af552924ec058e1b0c49a76180ee6'}]
STAGES = [('census-default-and-alt', 1800, ['/home/louistrue/.rustup/toolchains/nightly-2025-11-15-x86_64-unknown-linux-gnu/bin/cargo', 'test', '--locked', '-p', 'ifc-lite-geometry', '--features', 'triangulation-alt', '--test', 'triangulation_invariance', 'watertightness_census_and_triangulator_invariance', '--', '--exact', '--nocapture', '--test-threads=1'])]



def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def save(name, value):
    temporary = OUT / (name + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(OUT / name)


def pins():
    actual = {}
    for name, expected in EXPECTED_PINS.items():
        root = Path(expected['path'])
        row = {'path': str(root),
            'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
            'diffSHA256': hashlib.sha256(subprocess.check_output(['git', 'diff'], cwd=root)).hexdigest(),
            'status': subprocess.check_output(['git', 'status', '--porcelain'], cwd=root, text=True)}
        if row != expected or subprocess.check_output(['git', 'diff', '--cached'], cwd=root):
            raise RuntimeError('Pinned candidate/RED source changed')
        actual[name] = row
    actual['Cargo.lockSHA256'] = hashlib.sha256((ROOT / 'Cargo.lock').read_bytes()).hexdigest()
    if actual['Cargo.lockSHA256'] != EXPECTED_LOCK_SHA256:
        raise RuntimeError('Cargo.lock changed')
    tree = subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=ROOT, text=True).strip()
    if tree != 'a192dea744ae8931fd8b857a7e27aef36c158ccd':
        raise RuntimeError('Exact cumulative source tree changed')
    actual['sourceTree'] = tree
    for pin in FIXTURE_PINS:
        if hashlib.sha256(Path(pin['path']).read_bytes()).hexdigest() != pin['sha256']:
            raise RuntimeError('Real MiniBIM/rvt01 fixture changed')
    if os.environ.get('IFC_LITE_REQUIRE_FIXTURES') != '1':
        raise RuntimeError('Required-fixture gate absent')
    actual['fixturePins'] = FIXTURE_PINS
    return actual


def guard():
    hold = Path('/home/louistrue/wt/.bench-hold')
    mem = next(int(line.split()[1]) for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))
    if hold.exists():
        raise RuntimeError('DEFER NEW START: shared bench hold PRESENT')
    if mem < 24 * 1024 * 1024:
        raise RuntimeError('DEFER NEW START: MemAvailable below24GiB')
    return {'at': now(), 'benchHoldAbsent': True, 'MemAvailableKiB': mem,
            'limits': {key: os.environ[key] for key in ('CARGO_BUILD_JOBS','RAYON_NUM_THREADS','RUST_TEST_THREADS')},
            'timingClaim': False}


def members(group):
    rows = []
    for item in Path('/proc').iterdir():
        if not item.name.isdigit():
            continue
        try:
            text = (item / 'stat').read_text()
            fields = text[text.rfind(')') + 2:].split()
            if int(fields[2]) == group:
                rows.append({'pid': int(item.name), 'state': fields[0], 'startTicks': fields[19]})
        except (FileNotFoundError, ProcessLookupError):
            continue
    return rows


def reap_adopted():
    while True:
        try:
            pid, _ = os.waitpid(-1, os.WNOHANG)
            if pid == 0:
                return
        except ChildProcessError:
            return


def retire(group):
    # Each stage gets a new session; only that owned group is eligible for retirement.
    for action, grace in [(None, .1), (signal.SIGTERM, 4), (signal.SIGKILL, 4)]:
        reap_adopted()
        if not members(group):
            return []
        if action is not None:
            try:
                os.killpg(group, action)
            except ProcessLookupError:
                pass
        end = time.monotonic() + grace
        while time.monotonic() < end:
            reap_adopted()
            if not members(group):
                return []
            time.sleep(.05)
    return members(group)


def main():
    if '--run' not in __import__('sys').argv:
        raise RuntimeError('Explicit root-authorized --run required')
    if OUT.exists():
        raise RuntimeError('Fresh results required; no automatic retry')
    OUT.mkdir()
    # Adopt/reap only this lane's orphaned descendants if a cargo child fails.
    if ctypes.CDLL(None).prctl(36, 1, 0, 0, 0) != 0:
        raise RuntimeError('Cannot establish owned child reaping')
    active_child = None
    started = time.monotonic()
    receipt = {'kind': '6940-parent26f538-unchanged-census-diagnostic-WSL', 'startedAt': now(), 'source': pins(),
        'cargoTargetDir': os.environ['CARGO_TARGET_DIR'], 'actualNice': os.getpriority(os.PRIO_PROCESS, 0),
        'dispatchGuard': '/home/louistrue/wt/.bench-hold absent; MemAvailable>=24GiB; shared ordinary host, no exclusive/timing claim', 'stages': [],
        'maxLaneSeconds': 1815, 'performanceQualified': False, 'failures': []}
    save('lane-start.json', receipt)
    print(json.dumps({'event': 'actual-lane-start', 'at': now(), 'pid': os.getpid(), 'head': HEAD}), flush=True)
    try:
        for name, limit, command in STAGES:
            if (OUT / 'stop-after-stage').exists():
                receipt['coordinatorBoundary'] = {'at': now(), 'remainingStage': name, 'stopFile': str(OUT / 'stop-after-stage')}
                break
            remaining = 1815 - (time.monotonic() - started)
            if remaining <= 0:
                raise RuntimeError('One-lane absolute budget exhausted')
            source_before = pins()
            try:
                admission = guard()
            except RuntimeError as error:
                receipt['deferredNewStart'] = {'stage': name, 'at': now(), 'reason': str(error)}
                break
            stage = {'name': name, 'startedAt': now(), 'command': command, 'pinsBefore': source_before,
                'admissionBefore': admission, 'timeoutSeconds': min(limit, remaining)}
            save(name + '-start.json', stage)
            print(json.dumps({'event': 'stage-start', 'name': name, 'at': now()}), flush=True)
            with (OUT / (name + '.stdout')).open('w') as stdout, (OUT / (name + '.stderr')).open('w') as stderr:
                child = subprocess.Popen(command, cwd=ROOT, stdout=stdout, stderr=stderr, start_new_session=True)
                active_child = child
                stage['pid'] = child.pid
                stage['processGroup'] = child.pid
                stage['initialOwnedProcesses'] = members(child.pid)
                save(name + '-start.json', stage)
                try:
                    stage['exitCode'] = child.wait(timeout=stage['timeoutSeconds'])
                except subprocess.TimeoutExpired:
                    stage['timedOut'] = True
                    stage['remainingOwnedProcesses'] = retire(child.pid)
                    stage['exitCode'] = child.wait(timeout=5)
                stage['remainingOwnedProcesses'] = retire(child.pid)
            active_child = None
            stage['finishedAt'] = now()
            stage['pinsAfter'] = pins()
            stage['postChildHoldPresent'] = Path('/home/louistrue/wt/.bench-hold').exists()
            stage['expectedExitCode'] = 0
            if name == 'census-default-and-alt':
                report = ROOT / 'target/watertightness_census.run.tsv'
                if report.is_file() and report.stat().st_mtime >= datetime.datetime.fromisoformat(stage['startedAt']).timestamp():
                    measured = report.read_text()
                    (OUT / 'watertightness_census.run.tsv').write_text(measured)
                    stage['actual13797Rows'] = [line for line in measured.splitlines() if line.startswith('various/rvt01.ifc\t13797\t')]
                    stage['committed13797Rows'] = [line for line in (ROOT / 'rust/geometry/tests/manifests/watertightness_census.tsv').read_text().splitlines() if line.startswith('various/rvt01.ifc\t13797\t')]
                else:
                    stage['actual13797Rows'] = []
            output = (OUT / (name + '.stdout')).read_text() + (OUT / (name + '.stderr')).read_text()
            semantic = True
            if name not in ('fixture-catalogue', 'workspace-exact-clippy'):
                stage['allReportedTestSummaries'] = re.findall(r'test result: [^\n]+', output)
                stage['reportedPassedTotal'] = sum(int(x) for x in re.findall(r'test result: ok\. (\d+) passed;', output))
                semantic = stage['reportedPassedTotal'] > 0
                if name == 'census-default-and-alt':
                    semantic = semantic and 'watertightness census (production triangulator)' in output and 'SKIPPED:' not in output and len(stage.get('actual13797Rows', [])) == 1
            if name == 'geometry-lib-topics':
                required = json.loads((Path('/home/louistrue/.t3/worktrees/ifc-lite/t3code-818b4671/work/6940/zbook-resume-20261017/wsl-upper-5933-native-preparation') / 'topic-test-names.json').read_text())
                missing = [test for test in required if not re.search(r'test [^\n]*' + re.escape(test) + r' \.\.\. ok', output)]
                stage['missingRequiredTopicTests'] = missing
                semantic = semantic and not missing
            if name == 'all-nine-real-slabs':
                semantic = semantic and stage.get('reportedPassedTotal', 0) >= 3 and 'skipping:' not in output.lower()
            stage['ok'] = stage['exitCode'] == 0 and semantic and not stage.get('timedOut') and not stage['remainingOwnedProcesses'] and not stage.get('admissionAfterFailure')
            receipt['stages'].append(stage)
            save(name + '-result.json', stage)
            save('lane-progress.json', receipt)
            print(json.dumps({'event': 'stage-end', 'name': name, 'at': now(), 'ok': stage['ok'], 'exitCode': stage['exitCode']}), flush=True)
            if not stage['ok']:
                raise RuntimeError('Stage failed; authorized stop without fixes/retest: ' + name)
            if (OUT / 'stop-after-stage').exists():
                receipt['coordinatorBoundary'] = {'at': now(), 'afterStage': name, 'stopFile': str(OUT / 'stop-after-stage')}
                break
    except BaseException as error:
        receipt['failures'].append(str(error))
    finally:
        if active_child is not None:
            receipt['emergencyOwnedRemaining'] = retire(active_child.pid)
            try:
                active_child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                receipt['failures'].append('Owned child failed bounded retirement')
        reap_adopted()
        try:
            receipt['pinsAfter'] = pins()
        except RuntimeError as error:
            receipt['failures'].append(str(error))
        receipt['finishedAt'] = now()
        receipt['elapsedSeconds'] = time.monotonic() - started
        receipt['ok'] = len(receipt['stages']) == len(STAGES) and all(s['ok'] for s in receipt['stages']) and not receipt['failures']
        receipt['remainingStagesNotRun'] = [name for name, _, _ in STAGES if name not in {s['name'] for s in receipt['stages']}]
        save('lane-result.json', receipt)
        print(json.dumps({'event': 'actual-lane-end', 'at': now(), 'ok': receipt['ok'], 'failures': receipt['failures']}), flush=True)
    return 0 if receipt['ok'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
