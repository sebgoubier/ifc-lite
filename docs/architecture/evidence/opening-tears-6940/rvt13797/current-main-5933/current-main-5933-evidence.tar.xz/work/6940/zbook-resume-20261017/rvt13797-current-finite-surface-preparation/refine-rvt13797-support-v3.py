"""Evidence only: convex supporting-line refinement of loose v2 cells, no tolerances."""
from pathlib import Path
import json,time,hashlib
base=Path(__file__).resolve().parent;ns={'__file__':str(base/'analyze-rvt13797-full-triangle-support-v2.py')}
exec((base/'analyze-rvt13797-full-triangle-support-v2.py').read_text().split('started=time.time();')[0],ns)
np=ns['np'];Polygon=ns['Polygon'];lift=ns['lift'];distances=ns['distances'];mesh=ns['mesh']
v2=json.load(open(Path('/home/louistrue/.t3/worktrees/ifc-lite/t3code-818b4671/work/6940/zbook-resume-20261017/rvt13797-current-finite-surface-actual/rvt-causal/13797-full-triangle-support-needle-v2.json')));docs={k:json.load(open(p)) for k,p in ns['paths'].items()}

def cross(e,p):return e[0]*p[:,1]-e[1]*p[:,0]
def clip(poly,a,e,positive):
 d=cross(e,poly-a);inside=d>=0 if positive else d<=0;out=[]
 for i in range(len(poly)):
  j=(i+1)%len(poly)
  if inside[i]:out.append(poly[i])
  if inside[i]!=inside[j]:out.append(poly[i]+(poly[j]-poly[i])*(d[i]/(d[i]-d[j])))
 return np.array(out)
def bound(p,targets,eligible):
 d=distances(p,targets).max(axis=0);return float(d.min()),float(np.where(eligible,d,np.inf).min())
start=time.time();rows=[]
for row in v2['rows']:
 src,dst=row['direction'].split('→');ss=mesh(docs[src],row['alternate']);tt=mesh(docs[dst],row['alternate']);nn=np.cross(tt[:,1]-tt[:,0],tt[:,2]-tt[:,0]);records=[]
 for rec in row['records']:
  t=ss[rec['sourceTriangle']];ax=rec['projectionDroppedAxis'];axes=[i for i in range(3) if i!=ax];a=t[:,axes];b=tt[:,:,axes];normal=np.cross(t[1]-t[0],t[2]-t[0]);eligible=(nn*normal).sum(1)>0
  for ci,c in enumerate(rec['cellWitnesses']):
   if c['bound']<=1/65536 and c['sameHemisphereBound']<=1/65536:continue
   p=np.array(c['verticesProjected2D']);hull=Polygon(p).convex_hull
   if hull.geom_type!='Polygon':continue
   p=np.array(hull.exterior.coords[:-1]);lo=p.min(0);hi=p.max(0);overlap=(b.max(1)>=lo).all(1)&(b.min(1)<=hi).all(1);pieces=[p];budget=False
   for j in np.nonzero(overlap)[0]:
    for k in range(3):
     q=b[j,k];e=b[j,(k+1)%3]-q
     if not np.any(e):continue
     fresh=[]
     for poly in pieces:
      d=cross(e,poly-q)
      if (d>0).any() and (d<0).any():
       for sign in [True,False]:
        part=clip(poly,q,e,sign)
        if len(part)>=3:fresh.append(part)
      else:fresh.append(poly)
     pieces=fresh
     if len(pieces)>20000:budget=True;break
    if budget:break
   mx=mo=0.;worst=None
   for part in pieces:
    xyz=lift(part,a,t);x,y=bound(xyz,tt,eligible)
    if max(x,y)>max(mx,mo):worst={'vertices3D':xyz.tolist(),'bound':x,'sameHemisphereBound':y}
    mx=max(mx,x);mo=max(mo,y)
   records.append({'triangle':rec['sourceTriangle'],'cell':ci,'pieces':len(pieces),'budgetReached':budget,'maximumBound':min(mx,c['bound']),'maximumSameHemisphereBound':min(mo,c['sameHemisphereBound']),'worstPiece':worst})
  if records and len(records)%20==0:print(row['direction'],row['alternate'],len(records),flush=True)
 unchanged=[c for rec in row['records'] for c in rec['cellWitnesses'] if c['bound']<=1/65536 and c['sameHemisphereBound']<=1/65536]
 out={'direction':row['direction'],'alternate':row['alternate'],'refinedCells':len(records),'maximumBound':max([r['maximumBound'] for r in records]+[c['bound'] for c in unchanged]),'maximumSameHemisphereBound':max([r['maximumSameHemisphereBound'] for r in records]+[c['sameHemisphereBound'] for c in unchanged]),'records':records};rows.append(out);print({k:v for k,v in out.items() if k!='records'},flush=True)
 result={'scope':'Diagnostic floating clipping. Every loose v2 cell replaced by convex hull superset and clipped by infinite target-edge supporting lines; all pieces retained; min with original sound bound. Fixed finite convex target per piece. Kernel grid used only to select cells to refine, never acceptance. No multiplicity claim.','seconds':time.time()-start,'scriptSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':rows};(Path('/home/louistrue/.t3/worktrees/ifc-lite/t3code-818b4671/work/6940/zbook-resume-20261017/rvt13797-current-finite-surface-actual/rvt-causal/13797-full-triangle-support-needle-v3.json')).write_text(json.dumps(result,indent=2,allow_nan=False))
