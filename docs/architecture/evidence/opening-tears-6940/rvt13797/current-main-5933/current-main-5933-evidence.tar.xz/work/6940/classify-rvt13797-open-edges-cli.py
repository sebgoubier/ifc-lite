"""Evidence-only paired actual13797 newly unbalanced edge locations; no gate/waiver."""
from pathlib import Path
import json,struct,collections,hashlib,sys
from fractions import Fraction
import numpy as np
root=Path(__file__).resolve().parent
ns={'__file__':str(root/'analyze-rvt-physical.py')};exec((root/'analyze-rvt-physical.py').read_text().split('rows=[]')[0],ns)
f64=ns['f64'];f32s=ns['f32s'];distance=ns['distances']
paths={'bfa':root/'rvt-causal/kernel-no-cap-primary-alt-source-cut/rvt-payload.json','candidate':Path(sys.argv[1]).resolve()}
data={k:json.load(open(p)) for k,p in paths.items()};oracle=json.load(open(root/'rvt-four-wall-authoring-oracle-085-v1/13797-cut.json'));place=np.array(oracle['placementInIfcUnits']);reference=(np.array(oracle['vertices']).reshape(-1,3)-place[:3,3])@place[:3,:3];reftri=reference[np.array(oracle['faces']).reshape(-1,3)]
def edges(doc,alt):
 row=next(r for r in doc['rows'] if r['host']==13797 and r['alternate']==alt and r['context']=='all');rtc=np.array([f64(v) for v in doc['modelFrameRtcOffsetBits']]);p=f32s(row['positionsBits']).reshape(-1,3);q=np.copysign(np.floor(abs(p*1000)+.5),p).astype(np.int64);local=(p+np.array([f64(v) for v in row['originBits']])+(rtc-place[:3,3]))@place[:3,:3];faces=np.array(row['indices']).reshape(-1,3);uses=collections.defaultdict(list)
 for ti,t in enumerate(faces):
  a,b,c=map(tuple,q[t])
  if a==b or b==c or c==a:continue
  for i,j in [(0,1),(1,2),(2,0)]:
   x,y=tuple(q[t[i]]),tuple(q[t[j]]);uses[(min(x,y),max(x,y))].append((x<y,ti,int(t[i]),int(t[j])))
 result={}
 for key,ev in uses.items():
  f=int(sum(e[0] for e in ev));r=len(ev)-f
  if f==r:continue
  t=local[[ev[0][2],ev[0][3]]];result[key]={'forward':f,'reverse':r,'points':t,'storedPoints':p[[ev[0][2],ev[0][3]]],'incidentTriangles':[e[1] for e in ev]}
 return row,result
def exact_old_segment_cover(segment, old):
 a,b=[[Fraction(float(x)) for x in v] for v in segment];d=[b[i]-a[i] for i in range(3)];axis=next(i for i,x in enumerate(d) if x);lo,hi=sorted((a[axis],b[axis]));intervals=[]
 for r in old.values():
  c,e=[[Fraction(float(x)) for x in v] for v in r['storedPoints']]
  def collinear(v):
   z=[v[i]-a[i] for i in range(3)]
   return all(z[i]*d[j]==z[j]*d[i] for i in range(3) for j in range(i))
  if not collinear(c) or not collinear(e):continue
  l,h=sorted((c[axis],e[axis]));l=max(l,lo);h=min(h,hi)
  if l<=h:intervals.append((l,h))
 position=lo
 for l,h in sorted(intervals):
  if l>position:return False
  position=max(position,h)
  if position>=hi:return True
 return False
rows=[]
for alt in [False,True]:
 br,b=edges(data['bfa'],alt);nr,n=edges(data['candidate'],alt);assert br['originBits']==nr['originBits'];bs=np.array([r['points'] for r in b.values()]);records=[]
 for key,r in n.items():
  if key in b:continue
  p=r['points'];samples=np.concatenate([p,p.mean(axis=0)[None,:]]);a=bs[:,0];e=bs[:,1]-a;e2=(e*e).sum(1);near=[]
  for v in samples:
   t=np.clip(((v-a)*e).sum(1)/e2,0,1);d=np.linalg.norm(v-(a+e*t[:,None]),axis=1);near.append(float(d.min()))
  interface=min(float(np.max(abs(p[:,1]-v))) for v in [-.125,.125]);skin=min(float(np.max(abs(p[:,1]-v))) for v in [-.137,.137]);oracleD=distance(samples,reftri)
  records.append({'forward':r['forward'],'reverse':r['reverse'],'exactStoredSegmentCoveredByBaselineOpenSegments':exact_old_segment_cover(r['storedPoints'],b),'pointsHostLocal':p.tolist(),'nearestOneInterfacePlaneMaximumEndpointDistance':interface,'nearestOneSkinPlaneMaximumEndpointDistance':skin,'oracleFiniteSurfaceDistancesEndpointsAndMidpoint':oracleD.tolist(),'nearestOldUnbalancedSegmentDistancesEndpointsAndMidpoint':near,'incidentTriangles':r['incidentTriangles']})
 out={'alternate':alt,'baselineOpenEdges':len(b),'newOpenEdges':len(n),'unchangedExactStored1mmOpenEdgeKeys':len(set(b)&set(n)),'removedOldOpenEdgeKeys':len(set(b)-set(n)),'newOnlyOpenEdgeKeys':len(records),'newOnlyEdges':records};rows.append(out);print(alt,{k:v for k,v in out.items() if k!='newOnlyEdges'});print('max distance to old',max(max(x['nearestOldUnbalancedSegmentDistancesEndpointsAndMidpoint']) for x in records),'max oracle',max(max(x['oracleFiniteSurfaceDistancesEndpointsAndMidpoint']) for x in records))
Path(sys.argv[2]).write_text(json.dumps({'scope':'Actual paired stored1mm topology, rawhostlocal geometry via actualRTC/origin/authoredinverse; nearest finite surface/oldseam measurements only. No fullshape equivalence or automatic allowance.','scriptSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'payloadSHA256':{k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in paths.items()},'rows':rows},indent=2))
