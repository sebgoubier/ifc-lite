Approve only the explained RVT13797 census-row migration for exact parent26f538 → candidate5933. This proposal is not applied.

The recovered cap keeps the exact authored f64 oriented boundary and area, and fixes one local f32-nonpositive face in each of four contexts of the same profile. Scalar points stay unchanged. The final Boolean output is a mixed retessellation, not an exact3Dsurface identity.

The current complete finite-face diagnostics cover changed triangles in both directions and both modes, with no refinement budget exhaustion. Exact depth-separated projected multiplicity preserves both exterior Y skins; side/interior differences are disclosed. Every new exterior open or strict segment lies in a prior defect-segment union. STRICT DEFAULT126→131 includes all directed-pair violations; its46newkeys comprise40internal and6exterior, all six exactly covered by prior strict seams. ALTstrict117→114 has24newinternalkeys, including6balancedmultiplicity violations. These observations explain the change as the inherited bounded needle repair without declaring the alreadyopen/nonmanifold aggregate fixed.

Only the13797 row changes:65/394/collapsed1/ALT85/noVoid40/strict126 →101/379/collapsed0/ALT85/noVoid34/strict131. No new tolerance, acceptance band, golden-wide replacement or model-specific production branch is introduced. The original census FAIL, invalidV1capture and exact3Dchain differences remain evidence.

Root should review and apply the one-row patch, then run the unchanged DEFAULT+ALT census on the frozen metadata change. CI, performance and other landing requirements remain separate.
