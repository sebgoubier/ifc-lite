"""Inert adaptation of run-rvt-census-payload.py; exact two arms, one real host."""
import ctypes,datetime,hashlib,importlib.util,json,os,pathlib,signal,subprocess,sys,time
PREP=pathlib.Path(__file__).resolve().parent
REPO=PREP.parents[3]
SOURCE=REPO/'work/6940'
OUT=PREP.parent/'rvt13797-paired-export-v2-actual'
TARGET=pathlib.Path('/home/louistrue/.cache/ifc6940/targets/integration-463d3b0-20261017')
TOOL=pathlib.Path('/home/louistrue/.rustup/toolchains/nightly-2025-11-15-x86_64-unknown-linux-gnu/bin')
LIFECYCLE=PREP.parent/'wsl-parent-26f538-census-preparation/driver.py'
ARMS=[('parent',pathlib.Path('/home/louistrue/wt/6940-parent-26f538-census-20261018'),'26f538d7cdf21b6da66ebab1129b059d3945b390'),('top',pathlib.Path('/home/louistrue/wt/6940-upper-5933-validation-20261018'),'5933a21de2229b8b404b696551550011f209a852')]
FIXTURE_SHA='a83e9aacb43c7f82955ee3ba650ec66dc24af552924ec058e1b0c49a76180ee6'
EXPECTED=json.loads((PREP/'source-hashes.json').read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root)
def source(root,head):
 assert git(root,'rev-parse','HEAD').decode().strip()==head
 assert git(root,'status','--porcelain')==b'' and git(root,'diff','--cached')==b''
 return {'head':head,'tree':git(root,'rev-parse','HEAD^{tree}').decode().strip(),'Cargo.lockSHA256':sha((root/'Cargo.lock').read_bytes())}
def assert_idle():
 skip=set();pid=os.getpid()
 while pid>1:
  skip.add(pid)
  try:text=pathlib.Path('/proc',str(pid),'stat').read_text();pid=int(text[text.rfind(')')+2:].split()[1])
  except(FileNotFoundError,ProcessLookupError):break
 for item in pathlib.Path('/proc').iterdir():
  if not item.name.isdigit()or int(item.name)in skip:continue
  try:
   cwd=os.readlink(item/'cwd');roots=[str(root)for _,root,_ in ARMS]
   busy=any(cwd==root or cwd.startswith(root+'/')for root in roots)
   if not busy:
    try:busy=any(v==b'CARGO_TARGET_DIR='+str(TARGET).encode()for v in(item/'environ').read_bytes().split(b'\0'))
    except(PermissionError,FileNotFoundError,ProcessLookupError):pass
   assert not busy,'Source/cache has live process; refuse competing start: '+item.name
  except(PermissionError,FileNotFoundError,ProcessLookupError):pass
def main():
 assert sys.argv[1:]==['--run'],'Explicit later root authorization required'
 lane_started=time.monotonic();dispatch_deadline=lane_started+885
 assert not OUT.exists(),'Fresh evidence directory required; no retry'
 assert_idle()
 assert TARGET.is_dir()and TARGET.resolve()==TARGET,'Only exact owned cache directory eligible for selective package clean'
 for name,want in EXPECTED.items():assert sha(pathlib.Path(name).read_bytes())==want,name
 spec=importlib.util.spec_from_file_location('existing_owned_lifecycle',LIFECYCLE);life=importlib.util.module_from_spec(spec);spec.loader.exec_module(life)
 assert os.getpriority(os.PRIO_PROCESS,0)>=10,'Launch under nice10'
 assert ctypes.CDLL(None).prctl(36,1,0,0,0)==0
 def interrupted(signum,frame):raise SystemExit('Owned lane interrupted; restore sources')
 signal.signal(signal.SIGTERM,interrupted)
 os.environ.update(CARGO_BUILD_JOBS='2',RUST_TEST_THREADS='2',RAYON_NUM_THREADS='2',CARGO_TARGET_DIR=str(TARGET),RUSTC=str(TOOL/'rustc'),RUSTDOC=str(TOOL/'rustdoc'),IFC_LITE_REQUIRE_FIXTURES='1',IFC_LITE_PRISM_CUT='1')
 os.environ.pop('IFCLITE_CENSUS_BLESS',None);os.environ.pop('IFCLITE_TRIANGULATION_ALT',None)
 removed_budget_overrides={key:os.environ.pop(key,None)for key in ['IFC_LITE_CSG_BUDGET','IFC_LITE_CSG_ELEMENT_BUDGET','IFC_LITE_ELEMENT_BUDGET']}
 os.environ['PATH']=str(TOOL)+':'+os.environ.get('PATH','')
 before={name:source(root,head)for name,root,head in ARMS}
 OUT.mkdir();receipt={'status':'RUNNING_NO_GEOMETRY_VERDICT','startedAt':life.now(),'sources':before,'target':str(TARGET),'cacheReuse':'Own463d then9243/5933/26fcompilecache only; all prior results retain authentic sources','stages':[],'restoration':[],'failures':[],'debugGeometryFeature':False,'performanceClaim':False,'removedBudgetOverrides':removed_budget_overrides,'normalProductionBudgetDefaultsRequired':True,'maxLaneSeconds':900,'dispatchBudgetSeconds':885,'cleanupReserveSeconds':15,'buildMaxSeconds':300,'payloadMaxSeconds':120,'packageCleanMaxSeconds':60,'priorAttempt':'V1 topINVALID stale parent binary despite0exit; preserve all oldartifacts, notaccepted/pooled'}
 save(OUT/'start.json',receipt)
 active=None;cleanup_done=False
 try:
  for name,root,head in ARMS:
   d=OUT/name;d.mkdir();fixture=root/'tests/models/various/rvt01.ifc';assert sha(fixture.read_bytes())==FIXTURE_SHA
   example=root/'rust/processing/examples/diag7633rvt.rs';helper=example.with_name('diag7633rvt_rtc.rs');cap=root/'rust/geometry/src/profile_cap.rs'
   assert not example.exists() and not helper.exists();assert source(root,head)==before[name]
   rtc=(root/'rust/geometry/tests/corpus/rtc_frame.rs').read_bytes();original_cap=cap.read_bytes()if cap.exists()else None
   assert (name=='top')==(original_cap is not None)
   try:
    example.write_bytes((SOURCE/'rvt-census-payload.rs').read_bytes());helper.write_bytes(rtc+b"\nimpl ModelFrame<'_> { pub fn diagnostic_offset(&self) -> (f64,f64,f64) { self.offset } }\n")
    if name=='top':
     needle=b'pub(super) fn recover_missing_boundaries(\n    data: &[f64],\n    holes: &[usize],\n    earcut: &[usize],\n) -> Option<Vec<usize>> {'
     assert original_cap.count(needle)==1
     cap.write_bytes(original_cap.replace(needle,(SOURCE/'rvt-profile-cap-trace-wrapper.rs').read_bytes().rstrip()))
    env=os.environ.copy();env['IFC_DIAG_7631_RVT_TRACE']=str(d/'cap-stages.jsonl')
    save(d/'temporary-source.json',{'head':head,'RTCsourceSHA256':sha(rtc),'exporterSHA256':sha(example.read_bytes()),'helperSHA256':sha(helper.read_bytes()),'capTrace':name=='top','trackedPatch':git(root,'diff','--binary','HEAD').decode()})
    commands=[('package-clean',[str(TOOL/'cargo'),'clean','--locked','--package','ifc-lite-geometry','--package','ifc-lite-processing','--target-dir',str(TARGET)]),('build',[str(TOOL/'cargo'),'build','--locked','-p','ifc-lite-processing','--example','diag7633rvt','--features','ifc-lite-geometry/triangulation-alt']),('payload',[str(TARGET/'debug/examples/diag7633rvt'),str(fixture),str(d/'rvt-payload.json'),'13797'])]
    for stage,command in commands:
     remaining=dispatch_deadline-time.monotonic();assert remaining>0,'Whole900s lane dispatch budget exhausted; cleanupreserved'
     stage_limit=min({'package-clean':60,'build':300,'payload':120}[stage],remaining)
     if stage=='package-clean':assert_idle()
     admission=life.guard();assert git(root,'rev-parse','HEAD').decode().strip()==head
     assert sha((root/'Cargo.lock').read_bytes())==before[name]['Cargo.lockSHA256']
     s={'arm':name,'stage':stage,'startedAt':life.now(),'command':command,'admission':admission,'timeoutSeconds':stage_limit};save(d/(stage+'-start.json'),s)
     print(json.dumps({'event':'actual-child-start','arm':name,'stage':stage,'at':life.now()}),flush=True)
     if stage=='payload':
      assert sha((TARGET/'debug/examples/diag7633rvt').read_bytes())==binary_proof['binarySHA256'],'Produced binary changed before payload'
     with (d/(stage+'.stdout')).open('x')as stdout,(d/(stage+'.stderr')).open('x')as stderr:
      active=subprocess.Popen(command,cwd=root,env=env,stdout=stdout,stderr=stderr,start_new_session=True);cleanup_done=False;s['pid']=active.pid;s['processGroup']=active.pid;s['initialOwnedProcesses']=life.members(active.pid);save(d/(stage+'-start.json'),s)
      try:s['exitCode']=active.wait(timeout=stage_limit)
      except subprocess.TimeoutExpired:s['timedOut']=True
      s['remaining']=life.retire(active.pid);cleanup_done=True
      try:s['exitCode']=active.wait(timeout=5)
      except subprocess.TimeoutExpired:s['exitCode']=None;s['ownershipNotReleased']=True
      s['remaining']=life.members(active.pid)
     if not s['remaining']and active.poll()is not None:active=None
     else:s['ownershipNotReleased']=True
     s['finishedAt']=life.now();s['ok']=s.get('exitCode')==0 and not s.get('timedOut')and not s['remaining']and not s.get('ownershipNotReleased');receipt['stages'].append(s);save(d/(stage+'-result.json'),s)
     if s['ok']and stage=='build':
      binary=TARGET/'debug/examples/diag7633rvt';dep=TARGET/'debug/examples/diag7633rvt.d';text=dep.read_text()
      for required in [str(example),str(helper),str(root/'rust/geometry/src/'),str(root/'rust/processing/src/')]:assert required in text,'Selected source absent from producedbinary depfile: '+required
      cap_dependency=str(root/'rust/geometry/src/profile_cap.rs')
      assert (cap_dependency in text)==(name=='top'),'Top must compile cap dependency; parent must not contain cap dependency'
      for other,otherroot,_ in ARMS:
       if other!=name:assert str(otherroot)+'/'not in text,'Stale alternate-worktree depfile'
      binary_proof={'binary':str(binary),'binarySHA256':sha(binary.read_bytes()),'depfile':str(dep),'depfileSHA256':sha(dep.read_bytes()),'selectedRoot':str(root),'currentGeometryAndProcessingDependenciesPresent':True,'noOtherArmDependencies':True,'capDependencyPresent':cap_dependency in text};save(d/'produced-binary-provenance.json',binary_proof);(d/'produced-example.d').write_text(text)
     if s['ok']and stage=='payload':assert sha((TARGET/'debug/examples/diag7633rvt').read_bytes())==binary_proof['binarySHA256'],'Produced binary changed during payload'
     assert s['ok'],'Failed stage retained; no retry'
    data=json.loads((d/'rvt-payload.json').read_text());assert len(data['rows'])==4 and {(r['host'],r['alternate'],r['context'])for r in data['rows']}=={(13797,a,c)for a in [False,True]for c in ['source','all']}
    primary=next(r for r in data['rows']if r['context']=='all'and r['alternate']is False)
    expected_triangles=394 if name=='parent'else 379
    assert len(primary['indices'])//3==expected_triangles,'INVALID diagnostic: raw primaryall trianglecount differs authentic current canonical census'
    events=[json.loads(line)for line in(d/'cap-stages.jsonl').read_text().splitlines()]
    cap_events=[e for e in events if e.get('event')=='cap-recovery']
    if name=='top':assert cap_events,'INVALID top diagnostic: no actualcap trace events'
    else:assert not cap_events,'Parent unexpectedly emitted cap events'
    save(d/'payload-identity.json',{'fileSHA256':sha((d/'rvt-payload.json').read_bytes()),'fourActualRows':True,'diagnosticNotAcceptance':True,'expectedCanonicalPrimaryTriangles':expected_triangles,'actualCanonicalPrimaryTriangles':len(primary['indices'])//3,'capEvents':len(cap_events),'triangles':[{'alternate':r['alternate'],'context':r['context'],'triangles':len(r['indices'])//3}for r in data['rows']]})
   finally:
    if active is not None:
     if not cleanup_done:receipt['emergencyRemaining']=life.retire(active.pid);cleanup_done=True
     try:active.wait(timeout=5)
     except subprocess.TimeoutExpired:receipt['failures'].append('Owned child not reaped')
     remaining=life.members(active.pid)
     if remaining or active.poll()is None:
      receipt['ownershipNotReleased']={'arm':name,'processGroup':active.pid,'remaining':remaining,'at':life.now()};rr={'arm':name,'sourceExactlyRestored':False,'sourceRestorationDeferredWhileOwnedProcessAlive':True,'remainingOwnedProcesses':remaining};receipt['restoration'].append(rr);save(d/'restoration.json',rr);raise RuntimeError('OWNERSHIP_NOT_RELEASED: source restoration deferred; no lease handoff')
     active=None
    if original_cap is not None:cap.write_bytes(original_cap)
    example.unlink(missing_ok=True);helper.unlink(missing_ok=True)
    restored=source(root,head)==before[name] and (root/'rust/geometry/tests/corpus/rtc_frame.rs').read_bytes()==rtc
    if original_cap is not None:restored=restored and cap.read_bytes()==original_cap
    rr={'arm':name,'sourceExactlyRestored':restored,'temporaryExamplesRemoved':not example.exists()and not helper.exists()};receipt['restoration'].append(rr);save(d/'restoration.json',rr);assert restored
 except BaseException as error:receipt['failures'].append(str(error))
 finally:
  life.reap_adopted();receipt['finishedAt']=life.now();receipt['elapsedSeconds']=time.monotonic()-lane_started
  if receipt['elapsedSeconds']>900:receipt['failures'].append('Wholelane900s bound exceeded; no timing/ownershiprelease assumption')
  receipt['ok']=len(receipt['stages'])==6 and all(s['ok']for s in receipt['stages'])and len(receipt['restoration'])==2 and all(r['sourceExactlyRestored']for r in receipt['restoration'])and not receipt['failures'];save(OUT/'result.json',receipt);print(json.dumps({'event':'paired-export-finished-inspect-ownership','ok':receipt['ok'],'at':life.now(),'failures':receipt['failures']}),flush=True)
 return 0 if receipt['ok']else 1
if __name__=='__main__':raise SystemExit(main())
