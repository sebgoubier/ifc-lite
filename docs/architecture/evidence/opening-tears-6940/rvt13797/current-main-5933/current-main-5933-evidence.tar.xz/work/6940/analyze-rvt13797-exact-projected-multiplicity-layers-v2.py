"""Exact dyadic projection multiplicity L2 integral; evidence only, no tolerance."""
from pathlib import Path
from fractions import Fraction as F
import json,struct,collections,time,hashlib
import numpy as np
base=Path(__file__).resolve().parent
paths={'bfa':base/'rvt-causal/kernel-no-cap-primary-alt-source-cut/rvt-payload.json','needle':base/'final-cap-needle-only-proof-v1/rvt-needle-only-counterfactual-v1/rvt-payload.json'}
docs={k:json.load(open(v)) for k,v in paths.items()};oracle=json.load(open(base/'rvt-four-wall-authoring-oracle-085-v1/13797-cut.json'));mat=oracle['placementInIfcUnits'];R=[[F(mat[j][i]) for j in range(3)] for i in range(3)];T=[F(mat[i][3]) for i in range(3)]
def f64(s):return struct.unpack('>d',bytes.fromhex(s))[0]
def cross(a,b):return a[0]*b[1]-a[1]*b[0]
def sub(a,b):return (a[0]-b[0],a[1]-b[1])
def area(poly):return abs(sum(cross(poly[i],poly[(i+1)%len(poly)]) for i in range(len(poly))))/2 if len(poly)>2 else F(0)
def intersect(poly,tri):
 for i in range(3):
  if not poly:return []
  a,b=tri[i],tri[(i+1)%3];e=sub(b,a);out=[];ds=[cross(e,sub(p,a)) for p in poly]
  for j,p in enumerate(poly):
   q=poly[(j+1)%len(poly)];d,f=ds[j],ds[(j+1)%len(poly)]
   if d>=0:out.append(p)
   if (d>=0)!=(f>=0):
    h=d/(d-f);out.append((p[0]+h*(q[0]-p[0]),p[1]+h*(q[1]-p[1])))
  poly=out
 return poly

def groups(doc,alt):
 r=next(r for r in doc['rows'] if r['host']==13797 and r['alternate']==alt and r['context']=='all');raw=[F(float(struct.unpack('<f',struct.pack('<I',v))[0])) for v in r['positionsBits']];origin=[F(f64(v)) for v in r['originBits']];rtc=[F(f64(v)) for v in doc['modelFrameRtcOffsetBits']];ps=[]
 for i in range(0,len(raw),3):
  p=[raw[i+j]+origin[j]+rtc[j]-T[j] for j in range(3)];ps.append(tuple(sum(R[k][j]*p[j] for j in range(3)) for k in range(3)))
 g=collections.defaultdict(collections.Counter)
 for i in range(0,len(r['indices']),3):
  tri=[ps[j] for j in r['indices'][i:i+3]];a=[tri[1][j]-tri[0][j] for j in range(3)];b=[tri[2][j]-tri[0][j] for j in range(3)];n=[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];axis=max(range(3),key=lambda j:abs(n[j]));assert n[axis];axes=[j for j in range(3) if j!=axis];p=[tuple(v[j] for j in axes) for v in tri]
  if cross(sub(p[1],p[0]),sub(p[2],p[0]))<0:p.reverse()
  p=min(tuple(p[i:]+p[:i]) for i in range(3));layer=None
  if axis==1:
   # Four authored sheet levels separated by exact fixed midpoint planes.
   cuts=[(F(-.137)+F(-.125))/2,F(0),(F(.125)+F(.137))/2]
   lo=min(v[1] for v in tri);hi=max(v[1] for v in tri)
   low=sum(lo>x for x in cuts);high=sum(hi>x for x in cuts)
   assert low==high, ('Y-depth straddler',i//3,str(lo),str(hi))
   layer=low
  g[(axis,1 if n[axis]>0 else -1,layer)][p]+=1
 return g
# Behavioral mathematical controls: convex intersection, subdivisions and sheet multiplicity.
a=((F(0),F(0)),(F(2),F(0)),(F(0),F(2)))
b=((F(0),F(0)),(F(1),F(0)),(F(0),F(1)))
assert area(intersect(list(a),b))==F(1,2)
assert area(intersect(list(b),a))==F(1,2)
assert area(intersect(list(a),a))==2
assert area(intersect(list(a),tuple((x+3,y) for x,y in a)))==0
def l2_test(items):
 return sum(c*d*area(intersect(list(p),q)) for p,c in items for q,d in items)
assert l2_test([(a,1),(a,-1)])==0
assert l2_test([(a,2),(a,-1)])==2 # duplicate sheet cannot disappear
assert l2_test([(a,1)])==2 # missing sheet cannot disappear
left=((F(0),F(0)),(F(2),F(0)),(F(1),F(1)))
right=((F(0),F(0)),(F(1),F(1)),(F(0),F(2)))
assert l2_test([(a,1),(left,-1),(right,-1)])==0
start=time.time();rows=[]
for alt in [False,True]:
 gs={k:groups(doc,alt) for k,doc in docs.items()};out={'alternate':alt,'groups':[]}
 for key in sorted(set(gs['bfa'])|set(gs['needle'])):
  old=gs['bfa'].get(key,collections.Counter());new=gs['needle'].get(key,collections.Counter());d=old.copy();d.subtract(new);items=[(p,c) for p,c in d.items() if c];boxes=[(min(x for x,y in p),min(y for x,y in p),max(x for x,y in p),max(y for x,y in p)) for p,c in items];value=F(0);pairs=0
  for i,(p,c) in enumerate(items):
   value+=c*c*area(p)
   for j in range(i):
    a,b=boxes[i],boxes[j]
    if a[0]>=b[2] or b[0]>=a[2] or a[1]>=b[3] or b[1]>=a[3]:continue
    q,e=items[j];value+=2*c*e*area(intersect(list(p),q));pairs+=1
  assert value>=0
  row={'axis':key[0],'normalSign':key[1],'authoredYLayer':key[2],'oldTriangleInstances':sum(old.values()),'newTriangleInstances':sum(new.values()),'uncancelledProjectedTriangles':len(items),'intersectedPairs':pairs,'exactSquaredMultiplicityDifferenceIntegral':str(value),'squaredMultiplicityDifferenceIntegralFloat':float(value),'exactProjectedMultiplicityIdentical':value==0,'mismatchAreaUpperBound':float(value),'interpretation':'Counts are integers: area where multiplicity differs is <= integral of squared count difference; exact zero proves identical projected multiplicity almost everywhere. Does not establish depth pairing.'};out['groups'].append(row);print(alt,key,len(items),float(value),flush=True)
 rows.append(out)
 result={'scope':'Exact Fraction predicates/intersections/areas. Actual f32 positions plus f64origin/RTC and oracle fixed inverse-linear-frame operands treated as exact dyadic scalars, with NO intermediate float coordinate rounding. Dominant normal-axis/sign also exact. All triangle instance multiplicity retained; exact identical projected triangles cancel algebraically before pairwise convex clipping. L2 integral sum c_i*c_j*area(intersection). No tolerance, goldens or acceptance threshold. Projected area expressed in approximate authored frame; no depth identity claim.','seconds':time.time()-start,'scriptSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'sourceSHA256':{k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in paths.items()},'rows':rows};(base/'rvt-causal/13797-exact-projected-multiplicity-layers-v2.json').write_text(json.dumps(result,indent=2))
