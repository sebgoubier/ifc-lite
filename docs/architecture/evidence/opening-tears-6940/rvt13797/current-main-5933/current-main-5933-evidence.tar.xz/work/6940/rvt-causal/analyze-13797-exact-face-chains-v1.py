"""Bounded evidence-only exact dyadic 3D oriented finite triangle-domain comparison.
No snapping, coordinate fitting or tolerance. Shared actual RTC translation is
omitted from both arms; exact mesh origins are retained. Every support plane and
winding is separate, so coincident opposite-facing material interfaces remain.
"""
from pathlib import Path
from fractions import Fraction
import collections,functools,hashlib,json,math,struct
HERE=Path(__file__).resolve().parent
PATHS={'baseline':HERE/'kernel-no-cap-primary-alt-source-cut/rvt-payload.json',
       'candidate':HERE.parent/'final-cap-needle-only-proof-v1/rvt-needle-only-counterfactual-v1/rvt-payload.json'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dec(x):return struct.unpack('<f',struct.pack('<I',x))[0]
def dec64(x):return struct.unpack('>d',bytes.fromhex(x))[0]
def sub(a,b):return tuple(x-y for x,y in zip(a,b))
def cross(a,b):return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def primitive(v):
 g=functools.reduce(math.gcd,map(abs,v));assert g
 p=tuple(x//g for x in v);sign=1 if next(x for x in p if x)>0 else -1
 return tuple(x*sign for x in p),sign
def canonical(t):return min(t,t[1:]+t[:1],t[2:]+t[:2])
def encode(o):return json.dumps(o,separators=(',',':')).encode()
def digest(o):return hashlib.sha256(encode(o)).hexdigest()
def positions(row):
 o=tuple(Fraction(dec64(x)) for x in row['originBits'])
 v=row['positionsBits']
 return [tuple(Fraction(dec(v[i+k]))+o[k] for k in range(3))for i in range(0,len(v),3)]
def face_area(t,scale):
 n=cross(sub(t[1],t[0]),sub(t[2],t[0]));return math.sqrt(sum((x/scale**2)**2 for x in n))/2

def classify(row,pts,scale):
 planes=collections.defaultdict(lambda:collections.defaultdict(collections.Counter));faces=collections.defaultdict(list);collapsed=[];tris=[]
 for off in range(0,len(row['indices']),3):
  t=tuple(pts[i] for i in row['indices'][off:off+3]);tris.append(t);normal=cross(sub(t[1],t[0]),sub(t[2],t[0]))
  if normal==(0,0,0):collapsed.append(off//3);continue
  n,sign=primitive(normal);plane=(n,dot(n,t[0]),sign);faces[plane].append(off//3)
  for a,b in zip(t,t[1:]+t[:1]):
   d,_=primitive(sub(b,a));axis=next(i for i,x in enumerate(d)if x);line=(d,cross(d,a));aa,bb=a[axis],b[axis];direction=1 if bb>aa else -1;lo,hi=sorted([aa,bb]);planes[plane][line][lo]+=direction;planes[plane][line][hi]-=direction
 chains={}
 for plane,lines in planes.items():
  boundaries=[]
  for line,events in sorted(lines.items()):
   events={k:v for k,v in events.items()if v};keys=sorted(events);coverage=0;intervals=[]
   for i,k in enumerate(keys):
    coverage+=events[k]
    if i+1<len(keys)and coverage:
     end=keys[i+1]
     if intervals and intervals[-1][1]==k and intervals[-1][2]==coverage:intervals[-1]=(intervals[-1][0],end,coverage)
     else:intervals.append((k,end,coverage))
   assert coverage==0
   if intervals:boundaries.append((line,tuple(intervals)))
  chains[plane]=tuple(boundaries)
 return {'chains':chains,'faces':faces,'collapsed':collapsed,'tris':tris,'multiset':collections.Counter(canonical(t) for t in tris)}

def main():
 docs={k:json.loads(p.read_bytes())for k,p in PATHS.items()};assert docs['baseline']['modelFrameRtcOffsetBits']==docs['candidate']['modelFrameRtcOffsetBits'];maps={k:{(r['alternate'],r['context']):r for r in d['rows']if r['host']==13797}for k,d in docs.items()};out=[]
 for context in ['source','all']:
  for alt in [False,True]:
   rows={k:v[alt,context]for k,v in maps.items()};a,b=rows.values()
   assert a['originBits']==b['originBits'] and a['localToWorldBits']==b['localToWorldBits']
   # Compare in the common captured geometry frame. Retain identical placement
   # metadata; applying its common invertible transform cannot change equality.
   rational={k:positions(v)for k,v in rows.items()};scale=max(x.denominator for p in rational.values() for t in p for x in t);assert scale&(scale-1)==0
   points={k:[tuple(int(x*scale)for x in p)for p in ps]for k,ps in rational.items()};arms={k:classify(rows[k],points[k],scale)for k in rows};aa,bb=arms.values();keys=sorted(aa['chains'].keys()|bb['chains'].keys());changed=[p for p in keys if aa['chains'].get(p)!=bb['chains'].get(p)];common=aa['multiset']&bb['multiset'];removed=aa['multiset']-common;added=bb['multiset']-common
   rec={'host':13797,'alternate':alt,'context':context,'exactUnitsPerMeter':str(scale),'originBits':a['originBits'],'sharedLocalToWorldMetadataBits':a['localToWorldBits'],'exactOrientedFinitePlaneDomainsEqual':not changed,'beforeTriangles':len(aa['tris']),'afterTriangles':len(bb['tris']),'beforeCollapsedExactF32Faces':aa['collapsed'],'afterCollapsedExactF32Faces':bb['collapsed'],'exactOrientedCommonTrianglesWithMultiplicity':sum(common.values()),'removedTrianglesWithMultiplicity':sum(removed.values()),'addedTrianglesWithMultiplicity':sum(added.values()),'removedArea':sum(face_area(t,scale)*n for t,n in removed.items()),'addedArea':sum(face_area(t,scale)*n for t,n in added.items()),'beforeSupportPlaneDirections':len(aa['chains']),'afterSupportPlaneDirections':len(bb['chains']),'changedSupportPlaneDirections':len(changed),'changedPlanes':[]}
   for p in changed:
    n,offset,sign=p;entry={'primitiveNormal':list(map(str,n)),'offsetInIntegerUnits':str(offset),'winding':sign}
    for label,arm in arms.items():
     ids=arm['faces'].get(p,[]);ts=[arm['tris'][i]for i in ids]
     entry[label]={'faceIndices':ids,'area':sum(face_area(t,scale)for t in ts),'boundarySha256':digest(arm['chains'][p])if p in arm['chains']else None,'boundaryChains':arm['chains'].get(p),'trianglesExactInteger':ts}
    rec['changedPlanes'].append(entry)
   out.append(rec)
 report={'scope':__doc__,'scriptSHA256':sha(Path(__file__)),'payloadSHA256':{k:sha(p)for k,p in PATHS.items()},'sharedActualRtcBits':docs['baseline']['modelFrameRtcOffsetBits'],'rows':out,'limitations':['Equality of oriented planar boundaries certifies the compact finite triangle 2-chain on each exact plane, preserving multiplicity; it is not manifoldness or solid validity.','An inequality reports real exact dyadic surface differences, not their physical acceptability or a distance bound.','Material labels are absent from this merged router adapter; opposite winding is retained, but this is not a per-material completeness certificate.','Authored-plane coverage comparison is a separate independent analysis; no normal/plane snapping is used here.']}
 output=HERE/'13797-exact-face-chains-v1.json'
 with output.open('x')as f:json.dump(report,f,indent=2)
 print(json.dumps([{k:v for k,v in r.items()if k!='changedPlanes'}for r in out],indent=2))
if __name__=='__main__':main()
