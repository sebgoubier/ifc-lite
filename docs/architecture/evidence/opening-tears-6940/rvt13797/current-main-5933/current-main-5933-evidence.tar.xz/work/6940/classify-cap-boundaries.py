#!/usr/bin/env python3
"""Evidence-only exact rational oriented 2D boundary comparison; no tolerances."""
import collections
import fractions
import functools
import hashlib
import json
import math
from pathlib import Path
import struct

ROOT = Path(__file__).resolve().parent
INPUT = ROOT / 'rvt-causal/final11a-primary-alt-source-cut/cap-stages.jsonl'
OUTPUT = ROOT / 'rvt-causal/cap-exact-boundary-classification-v1.json'
F = fractions.Fraction

def area(a, b, c):
    return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])

def chains(edges, points):
    lines = collections.defaultdict(lambda: collections.defaultdict(int))
    for a, b in edges:
        a, b = points[a], points[b]
        if a == b:
            continue
        coefficients = (a[1]-b[1], b[0]-a[0], a[0]*b[1]-b[0]*a[1])
        scale = math.lcm(*(x.denominator for x in coefficients))
        integers = [int(x*scale) for x in coefficients]
        divisor = functools.reduce(math.gcd, integers)
        integers = [x//divisor for x in integers]
        if next(x for x in integers if x) < 0:
            integers = [-x for x in integers]
        key = tuple(integers)
        axis = 0 if a[0] != b[0] else 1
        x, y = a[axis], b[axis]
        lines[key][x] += 1
        lines[key][y] -= 1
    return {key: {x: v for x, v in events.items() if v}
            for key, events in lines.items() if any(events.values())}

def triangles(indices):
    assert len(indices) % 3 == 0
    for i in range(0, len(indices), 3):
        yield indices[i:i+3]

def tri_edges(indices):
    return [(t[k], t[(k+1)%3]) for t in triangles(indices) for k in range(3)]

rows = []
context = None
for line_number, line in enumerate(INPUT.read_text().splitlines(), 1):
    event = json.loads(line)
    if event['event'] == 'begin':
        context = {k: event[k] for k in ['host', 'alternate', 'context']}
    elif event['event'] == 'end':
        context = None
    elif event['event'] == 'cap-recovery' and event['result'] is not None:
        assert context is not None
        values = [F(struct.unpack('>d', bytes.fromhex(x))[0]) for x in event['dataBits']]
        points = list(zip(values[::2], values[1::2]))
        rings = []
        start = 0
        for end in event['holes'] + [len(points)]:
            ring = []
            for i in range(start, end):
                if not ring or points[i] != points[ring[-1]]:
                    ring.append(i)
            if len(ring) > 1 and points[ring[0]] == points[ring[-1]]:
                ring.pop()
            rings.append(ring)
            start = end
        expected = []
        for n, ring in enumerate(rings):
            signed = sum(points[ring[k]][0]*points[ring[(k+1)%len(ring)]][1]
                         - points[ring[(k+1)%len(ring)]][0]*points[ring[k]][1]
                         for k in range(len(ring)))
            assert signed != 0
            if (signed > 0) != (n == 0):
                ring = list(reversed(ring))
            expected += [(ring[k], ring[(k+1)%len(ring)]) for k in range(len(ring))]
        reference = chains(expected, points)
        before, after = event['earcut'], event['result']
        before_area = sum(area(*(points[i] for i in t)) for t in triangles(before))
        after_area = sum(area(*(points[i] for i in t)) for t in triangles(after))
        rows.append(context | {
            'traceLine': line_number,
            'earcutTriangles': len(before)//3,
            'cdtTriangles': len(after)//3,
            'earcutAllPositive': all(area(*(points[i] for i in t)) > 0 for t in triangles(before)),
            'cdtAllPositive': all(area(*(points[i] for i in t)) > 0 for t in triangles(after)),
            'earcutExactOrientedBoundaryEqualsAuthored': chains(tri_edges(before), points) == reference,
            'cdtExactOrientedBoundaryEqualsAuthored': chains(tri_edges(after), points) == reference,
            'earcutCdtExactAreaEqual': before_area == after_area,
            'twiceAreaDeltaExact': str(after_area-before_area),
        })
receipt = {
    'scope': 'Exact rational f64 2D positive-triangle boundary-chain comparison. Collinear subdivisions normalize algebraically; no numeric tolerances. This does not classify downstream 3D Boolean results.',
    'inputSha256': hashlib.sha256(INPUT.read_bytes()).hexdigest(),
    'scriptSha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'rows': rows,
}
with OUTPUT.open('x') as file:
    json.dump(receipt, file, indent=2)
    file.write('\n')
for row in rows:
    print(row)
